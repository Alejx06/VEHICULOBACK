Recuerda hacer las pruebas con una aplicación de tipo cliente como Postman, Insomnia, ThunderClient o la que prefieras.

Aquí te relaciono un ejemplo para el body de la petición: 

{
  "marca": "Mazda",
  "modelo": "3",
  "anio": 2022
}

Es tu trabajo ampliar las funcionalidades del proyecto para moto y un nuevo tio de vehiculo
